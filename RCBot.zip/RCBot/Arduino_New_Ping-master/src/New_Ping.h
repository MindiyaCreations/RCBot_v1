#pragma once
// stub header to correct discrepancy between 
// library name and source file names introduced
// by the creator of this library 

#include <NewPing.h>
